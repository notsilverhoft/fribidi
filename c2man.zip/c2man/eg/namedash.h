/*
 * NAME
 *	namedash - name section with dash.
 *
 * DESCRIPTION
 *	This function goes way over the top and includes a NAME section that
 *	has a dash in it.
 */
int namedash();
