/* generate a lot of silly values
 * Returns: Quite a number of things, as follows:
 *	0	nothing
 *	1	something small
 *	2	a little larger
 *	3	done in triplicate
 *	4	getting larger
 *	5	quintuplets
 *	6	that'll do now, although I think this one is going to get
 *		very long and even cover multiple lines. let's just hope that
 *		it gets it right, including the capitalisation. maybe this is
 *		not a super thorough test, so including some
 * .B bold
 *		stuff might help
 */
int returnlist();
