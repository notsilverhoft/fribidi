/* surrounded by comments.
 * this is the first one, and only it should be output.
 *
 * note: you'll need -v to get output from this.
 */
int surround;	/* this should NOT be output. */
