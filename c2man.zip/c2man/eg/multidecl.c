int multidecl1,	/* the first one */
    multidecl2,	/* the second one */
    multidecl3;	/* the last one */
