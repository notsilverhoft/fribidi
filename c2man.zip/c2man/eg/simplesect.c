/*
 * calculate some sections.
 * Note: this becomes the description.
 *
 * Warning: This becomes a section.
 */
int simplesect(
	int fred,	/* Mary's boyfriend */
	int world	/* real crazy */
)
{
	what the heck, all this stuff just gets ignored
}
