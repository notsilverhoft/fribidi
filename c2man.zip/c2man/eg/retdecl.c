/* return near the declarator
 * This is an example of embedding the `returns' information in near the
 * declarator in a function declaration.
 */
char *			/* a string, or NULL if it failed */
retdecl()
{
    /* reference implementation that barely meets the interface spec */
    return NULL;
}
